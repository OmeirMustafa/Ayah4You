export interface Ayah {
  englishText: string;
  surahName: string;
  surahNumber: number;
  ayahNumber: number | string;
}
